

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9"  />
<title><?php echo $title; ?></title>
<meta name="Description" content="<?php echo $aciklama; ?>">
<meta name="Keywords" content="<?php echo $anahtar_kelime; ?>" />
<script type="text/javascript" src="tema8/js/jquery.min.js"></script>

<script type="text/javascript" src="tema8/fancybox/jquery.fancybox-1.3.3.pack.js"></script>
<script type="text/javascript" src="tema8/fancybox/jquery.fancybox-1.3.3.js"></script>
<link rel="stylesheet" type="text/css" href="tema8/fancybox/jquery.fancybox-1.3.3.css" media="screen" />

<link rel="stylesheet" type="text/css" href="tema8/css/stil.css" />

<script type="text/javascript" src="http://cloud.github.com/downloads/malsup/cycle/jquery.cycle.all.2.74.js"></script>
<script type="text/javascript" src="tema8/js/vitrin.js"></script>

<script type="text/javascript">  

	$(document).ready(function(){
		
		$(".sonilanrow").mouseover(function(){
			$(this).css({ color:"red" });
		});
		
		$(".sonilanrow").mouseout(function(){
			$(this).css({ color:"black" });
		});
		
	});
		
</script>

<script type="text/javascript">
	$(document).ready(function() {

		$("a#foto").fancybox();
	});
</script>

<script type="text/javascript" src="yalniz_sayi.js"></script> 
<script type="text/javascript" src="getirici.js"></script>

</head>

<body >

<div id="sayfa">
	<div id="ust"><img src="tema8/res/logo.png" hspace="5" /></div>
    <div id="menu"><div class="menuitem"><a href="index.php" title="anasayfa" >ANASAYFA</a></div>

<div class="menuitem"><a href="index.php?action=arama&grup=1&liste=1" title="konut ilanlar�" >KONUT �LANLARI</a></div>
<div class="menuitem"><a href="index.php?action=arama&grup=2&liste=1" title="i�yeri ilanlar�" >��YER� �LANLARI</a></div>
<div class="menuitem"><a href="index.php?action=arama&grup=3&liste=1" title="arsa ilanlar�" >ARSA �LANLARI</a></div>
<div class="menuitem"><a href="index.php?action=emlakci_liste" title="emlak ofisleri" >EMLAK OF�SLER�</a></div>
<div class="menuitem"><a href="index.php?action=duyuru" title="Duyurular" >DUYURULAR</a></div>
<div class="menuitem"><a href="index.php?action=iletisim" title="ileti�im" >�LET���M</a></div></div>
   
 
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
